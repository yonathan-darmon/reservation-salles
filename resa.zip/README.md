# reservation-salles

Ce projet a pour but de créer une application de reservation de salles. Nous avons décidés avec Aurelien Adjimi et
Thomas Germany, de partir sur la reservation de la salle des goudes au parc chanot. 
 
